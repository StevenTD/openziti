export * from "./index-legacy";
import * as vis from "./index-legacy";
export { vis as default };
//# sourceMappingURL=index-legacy-bundle.d.ts.map