import moment from 'moment'
export = moment
