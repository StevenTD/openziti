export * from "./index-peer";
import * as util from "vis-util";
export { util };
import * as data from "vis-data";
export { data };
export { DataSet, DataView, Queue } from "vis-data";
//# sourceMappingURL=index-standalone.d.ts.map